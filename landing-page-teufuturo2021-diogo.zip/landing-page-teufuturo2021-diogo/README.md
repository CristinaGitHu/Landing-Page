# Landing Page #TeuFuturo 2021

O projeto constitui-se em uma Landing Page, proposta pela empresa patrocinadora do projeto #teuFuturo da turma da quarta-feira, Yaman. A landing page tem a temática: Um pouco sobre o #TeuFuturo.

[Confira a Landing Page](https://diogoizele.github.io/landing-page-teufuturo2021/)
